function createData(id, name, calor, option, sku, stock) {
  return { id, name, calor, option, sku, stock };
}

export const rows = {
  vegitables: [
    createData(1, "Cucumber", "#00B121", "Large", "SKU02596052", 24),
    createData(2, "Green Chilli", "#00B121", "Small", "SKU02596053", 43),
    createData(3, "Carrot", "#333333", "Medium", "SKU02596054", 0),
    createData(4, "Pottato", "#00B121", "Small", "SKU02596055", "Unlimited"),
  ],
  fruits: [
    createData(1, "Pineapple", "#FFDA00", "Medium", "SKU02596049", "Unlimited"),
    createData(2, "Banana", "#FFDA00", "Medium", "SKU02596050", "Unlimited"),
    createData(3, "Grren Apple", "#00B121", "Large", "SKU02596051", 24),
  ],
  breads: [
    createData(
      1,
      "Milk Bread",
      "#FFDA00",
      "Medium",
      "SKU02596048",
      "Unlimited"
    ),
  ],
};
