import React, { useState } from "react";
import Typography from "@material-ui/core/Typography";
import AddIcon from "@material-ui/icons/Add";
import RemoveIcon from "@material-ui/icons/Remove";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Switch from "@material-ui/core/Switch";
import { rows } from "../rowData";
import { SearchBox } from "./SearchBox";
import { TableHeader } from "./TableHeader";
import { TableAccordion } from "./TableAccordion";
import {
  AccordionDetails,
  AccordionSummary,
  Accordion,
  useStyles,
} from "./AccordionData";

export const App = () => {
  const classes = useStyles();
  const [expanded, setExpanded] = useState("");

  const handleChange = (panel) => (event, newExpanded) => {
    setExpanded(newExpanded ? panel : false);
  };

  return (
    <div className={classes.root}>
      <div className={classes.SearchMargin}>
        <SearchBox />
      </div>
      <TableHeader />
      <Accordion
        square
        expanded={expanded === "panel1"}
        onChange={handleChange("panel1")}
      >
        <AccordionSummary
          aria-controls="panel1d-content"
          id="panel1d-header"
          expandIcon={expanded !== "panel1" ? <AddIcon /> : <RemoveIcon />}
        >
          <Typography className={classes.heading}>
            Vegetables & Fruits
          </Typography>
          <Typography className={classes.secondaryHeading}>
            <FormControlLabel
              control={
                <Switch
                  checked={true}
                  onChange={handleChange}
                  color="primary"
                  value="dynamic-class-name"
                />
              }
              label="Availability"
              labelPlacement="start"
            />
          </Typography>
        </AccordionSummary>

        <AccordionDetails style={{ padding: 0 }}>
          <TableAccordion labelName="Vegitables" rowData={rows.vegitables} />
        </AccordionDetails>

        <AccordionDetails style={{ padding: 0 }}>
          <TableAccordion labelName="Fruits" rowData={rows.fruits} />
        </AccordionDetails>
      </Accordion>

      <Accordion
        square
        expanded={expanded === "panel2"}
        onChange={handleChange("panel2")}
        style={{ margin: "20px 0" }}
      >
        <AccordionSummary
          aria-controls="panel2d-content"
          id="panel2d-header"
          expandIcon={expanded !== "panel2" ? <AddIcon /> : <RemoveIcon />}
        >
          <Typography className={classes.heading}>Breads & Dairy</Typography>
          <Typography className={classes.secondaryHeading}>
            <FormControlLabel
              control={
                <Switch
                  checked={true}
                  onChange={handleChange}
                  color="primary"
                  value="dynamic-class-name"
                />
              }
              label="Availability"
              labelPlacement="start"
            />
          </Typography>
        </AccordionSummary>
        <AccordionDetails style={{ padding: 0 }}>
          <TableAccordion labelName="Breads" rowData={rows.breads} />
        </AccordionDetails>
      </Accordion>

      <Accordion
        square
        expanded={expanded === "panel3"}
        onChange={handleChange("panel3")}
        style={{ margin: "20px 0" }}
      >
        <AccordionSummary
          aria-controls="panel3d-content"
          id="panel3d-header"
          expandIcon={expanded !== "panel3" ? <AddIcon /> : <RemoveIcon />}
        >
          <Typography className={classes.heading}>Snaks</Typography>
          <Typography className={classes.secondaryHeading}>
            <FormControlLabel
              control={
                <Switch
                  checked={false}
                  onChange={handleChange}
                  color="primary"
                  value="dynamic-class-name"
                />
              }
              label="Availability"
              labelPlacement="start"
            />
          </Typography>
        </AccordionSummary>
        <AccordionDetails style={{ padding: 0 }}></AccordionDetails>
      </Accordion>

      <Accordion
        square
        expanded={expanded === "panel4"}
        onChange={handleChange("panel4")}
        style={{ margin: "20px 0" }}
      >
        <AccordionSummary
          aria-controls="panel4d-content"
          id="panel4d-header"
          expandIcon={expanded !== "panel4" ? <AddIcon /> : <RemoveIcon />}
        >
          <Typography className={classes.heading}>
            Cleaning And Household
          </Typography>
          <Typography className={classes.secondaryHeading}>
            <FormControlLabel
              control={
                <Switch
                  checked={false}
                  onChange={handleChange}
                  color="primary"
                  value="dynamic-class-name"
                />
              }
              label="Availability"
              labelPlacement="start"
            />
          </Typography>
        </AccordionSummary>
        <AccordionDetails style={{ padding: 0 }}></AccordionDetails>
      </Accordion>
    </div>
  );
};
