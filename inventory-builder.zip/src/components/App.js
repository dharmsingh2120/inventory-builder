import React, { useEffect, useState } from "react";
import Typography from "@material-ui/core/Typography";
import AddIcon from "@material-ui/icons/Add";
import RemoveIcon from "@material-ui/icons/Remove";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Switch from "@material-ui/core/Switch";
import { rows } from "./rowData";
import { SearchBox } from "./SearchBox";
import { TableHeader } from "./TableHeader";
import { TableAccordion } from "./TableAccordion";
import {
  AccordionDetails,
  AccordionSummary,
  Accordion,
  useStyles,
} from "./AccordionData";

export const App = () => {
  const classes = useStyles();
  const [expanded, setExpanded] = useState("");
  const [data, setData] = useState([]);
  const [color, setColor] = React.useState("blue");

  const handleToggleChange = (event) => {
    setColor(event.target.checked ? "blue" : "default");
  };

  useEffect(() => {
    setData(rows);
  }, []);

  const handleChange = (panel) => (event, newExpanded) => {
    setExpanded(newExpanded ? panel : false);
  };

  const handleUpdateTableData = (rowData, uData) => {
    console.log(rowData, uData);
    const newData = data.map((row) => {
      return {
        ...row,
        data: row.data.map((item) => {
          return {
            ...item,
            data: item.data.map((dt) => {
              if (dt.id === rowData.id) {
                return {
                  ...dt,
                  stock: uData.isUnlimited ? "unlimited" : uData.stockValue,
                };
              }
              return dt;
            }),
          };
        }),
      };
    });
    setData(newData);
  };

  return (
    <div className={classes.root}>
      <div className={classes.SearchMargin}>
        <SearchBox />
      </div>
      <TableHeader />
      {data.map((row) => (
        <Accordion
          square
          expanded={expanded === `panel${row.id}`}
          onChange={handleChange(`panel${row.id}`)}
          style={{ margin: row.id === 1 ? "0" : "16px 0px" }}
        >
          <AccordionSummary
            expandIcon={
              expanded !== `panel${row.id}` ? <AddIcon /> : <RemoveIcon />
            }
          >
            <Typography className={classes.heading}>{row.name}</Typography>
            <Typography className={classes.secondaryHeading}>
              <FormControlLabel
                control={
                  <Switch
                    checked={row.data.length > 0 && color === 'blue'}
                    onChange={handleToggleChange}
                    color="primary"
                    value="dynamic-class-name"
                  />
                }
                label="Availability"
                labelPlacement="start"
              />
            </Typography>
          </AccordionSummary>
          {row.data.length > 0 &&
            row.data.map((item) => {
              return (
                <AccordionDetails
                  style={{ padding: 0 }}
                  key={item.id}
                  aria-controls={`panel${row.id}d-content`}
                  id={`panel${row.id}d-header`}
                >
                  <TableAccordion
                    labelName={item.name}
                    rowData={item.data}
                    updataData={handleUpdateTableData}
                  />
                </AccordionDetails>
              );
            })}
        </Accordion>
      ))}
    </div>
  );
};
