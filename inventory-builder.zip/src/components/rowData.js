function createData(id, name, calor, option, sku, stock) {
  return { id, name, calor, option, sku, stock };
}

export const rows = [
  {
    id: 1,
    name: "Vegetables & Fruits",
    data: [
      {
        id: 11,
        name: "Vegitables",
        data: [
          createData(111, "Cucumber", "#00B121", "Large", "SKU02596052", 24),
          createData(
            112,
            "Green Chilli",
            "#00B121",
            "Small",
            "SKU02596053",
            43
          ),
          createData(113, "Carrot", "#333333", "Medium", "SKU02596054", 0),
          createData(
            114,
            "Pottato",
            "#00B121",
            "Small",
            "SKU02596055",
            "unlimited"
          ),
        ],
      },
      {
        id: 12,
        name: "Fruits",
        data: [
          createData(
            121,
            "Pineapple",
            "#FFDA00",
            "Medium",
            "SKU02596049",
            "unlimited"
          ),
          createData(
            122,
            "Banana",
            "#FFDA00",
            "Medium",
            "SKU02596050",
            "unlimited"
          ),
          createData(123, "Grren Apple", "#00B121", "Large", "SKU02596051", 24),
        ],
      },
    ],
  },
  {
    id: 2,
    name: "Breads & Dairy",
    data: [
      {
        id: 21,
        name: "breads",
        data: [
          createData(
            211,
            "Milk Bread",
            "#FFDA00",
            "Medium",
            "SKU02596048",
            "unlimited"
          ),
        ],
      },
    ],
  },
  {
    id: 3,
    name: "Snaks",
    data: [],
  },
  {
    id: 4,
    name: "Cleaning And Household",
    data: [],
  },
];
