import React, { useState } from "react";
import Table from "@material-ui/core/Table";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableRow from "@material-ui/core/TableRow";
import Typography from "@material-ui/core/Typography";
import Paper from "@material-ui/core/Paper";
import AddIcon from "@material-ui/icons/Add";
import RemoveIcon from "@material-ui/icons/Remove";
import TableBody from "@material-ui/core/TableBody";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Switch from "@material-ui/core/Switch";
import EditIcon from "@material-ui/icons/Edit";
import IconButton from "@material-ui/core/IconButton";
import Checkbox from "@material-ui/core/Checkbox";
import FormGroup from "@material-ui/core/FormGroup";
import SaveIcon from "@material-ui/icons/Save";
import Button from "@material-ui/core/Button";
import {
  AccordionDetails,
  AccordionSummary,
  Accordion,
  useStyles,
} from "./AccordionData";

export const TableAccordion = ({ labelName, rowData }) => {
  const classes = useStyles();
  const [childExpanded, setChildExpanded] = useState("");
  const [, setColor] = React.useState("default");
  
  const childHandleChange = (panel) => (event, newExpanded) => {
    setChildExpanded(newExpanded ? panel : false);
  };

  const handleChange = (event) => {
    setColor(event.target.checked ? "primary" : "default");
  };

  const [state, setState] = React.useState({
    checkedB: true,
  });

  const handleCheckbox = (event) => {
    setState({ ...state, [event.target.name]: event.target.checked });
  };

  return (
    <Accordion
      square
      expanded={childExpanded === labelName}
      onChange={childHandleChange(labelName)}
      style={{ width: "100%" }}
    >
      <AccordionSummary
        aria-controls={`${labelName}-content`}
        id={`${labelName}-header`}
        expandIcon={childExpanded !== labelName ? <AddIcon /> : <RemoveIcon />}
      >
        <Typography className={classes.heading}>{labelName}</Typography>
        <Typography className={classes.secondaryHeading}>
          <FormControlLabel
            control={
              <Switch
                checked={rowData.length > 0}
                onChange={handleChange}
                value="dynamic-class-name"
                color={rowData.length > 0 ? "primary" : "default"}
              />
            }
            label="Availability"
            labelPlacement="start"
          />
        </Typography>
      </AccordionSummary>
      <AccordionDetails style={{ padding: 0 }}>
        <Typography style={{ width: "100%" }}>
          <TableContainer component={Paper}>
            <Table aria-label="simple table">
              <TableBody>
                {rowData.map((row) => (
                  <TableRow key={row.id}>
                    <TableCell width={300}>{row.name}</TableCell>
                    <TableCell width={125}>{row.calor}</TableCell>
                    <TableCell width={125}>{row.option}</TableCell>
                    <TableCell width={125}>{row.sku}</TableCell>
                    <TableCell width={250}>
                      {labelName === "Vegitables" && row.id === 2 ? (
                        <FormGroup row>
                          <span style={{ paddingRight: "12px" }}>
                            <input
                              type="text"
                              placeholder="Enter Value"
                              style={{
                                width: "85px",
                                borderRadius: "25px",
                                padding: "12px",
                                border: "none",
                                backgroundColor: "rgba(0, 0, 0, 0.06)",
                              }}
                            />
                          </span>
                          <FormControlLabel
                            control={
                              <Checkbox
                                checked={state.checkedB}
                                onChange={handleCheckbox}
                                name="checkedB"
                                color="primary"
                              />
                            }
                            label="Unlimited"
                          />
                        </FormGroup>
                      ) : row.stock === 0 ? (
                        "--"
                      ) : (
                        row.stock
                      )}
                    </TableCell>
                    <TableCell align="right" width={100}>
                      {labelName === "Vegitables" && row.id === 2 ? (
                        <Button
                          variant="contained"
                          color="primary"
                          size="small"
                          className={classes.button}
                          endIcon={<SaveIcon />}
                          style={{ borderRadius: 25, boxShadow: "none" }}
                        >
                          Save
                        </Button>
                      ) : (
                        <IconButton aria-label="edit">
                          <EditIcon fontSize="small" />
                        </IconButton>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Typography>
      </AccordionDetails>
    </Accordion>
  );
};
