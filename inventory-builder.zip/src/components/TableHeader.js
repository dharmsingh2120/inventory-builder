import React from "react";
import Table from "@material-ui/core/Table";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";

export const TableHeader = () => {
  return (
    <TableContainer component={Paper} style={{ backgroundColor: 'rgba(0, 0, 0, .03)', boxShadow: 'none'}}>
      <Table aria-label="collapsible table">
        <TableHead>
          <TableRow>
            <TableCell width={300}>Item Name</TableCell>
            <TableCell width={125}>Colors</TableCell>
            <TableCell width={125}>Options</TableCell>
            <TableCell width={125}>SKU ID</TableCell>
            <TableCell width={250}>Stocks</TableCell>
            <TableCell align="right" width={100} >Actions</TableCell>
          </TableRow>
        </TableHead>
      </Table>
    </TableContainer>
  );
};
